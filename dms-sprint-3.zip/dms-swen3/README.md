# DMS – Sprint 3

Docker Desktop mit Linux-Containern starten und im Projektverzeichnis ausführen.

```powershell
docker compose build
docker compose up -d --wait
docker compose ps
```

Die Oberfläche ist unter `http://localhost` erreichbar. Im Formular **New Document** kann eine PDF mit bis zu 20 MiB ausgewählt werden. Der Upload lässt sich auch direkt testen. Dazu eine PDF als `beispiel.pdf` im Arbeitsverzeichnis verwenden.

```powershell
curl.exe -i -F "title=Sprint-3-Test" -F "file=@beispiel.pdf;type=application/pdf" http://localhost/api/documents
docker compose logs --tail 30 ocr-worker
```

Die API antwortet mit `201 Created` und einem `Location`-Header. Der Worker protokolliert innerhalb weniger Sekunden `Received document <id> for OCR processing (storage key: <key>)`. Im Storage-Bucket `documents` liegt die PDF unter diesem Schlüssel.

## Ablauf für das Code-Review

- Nginx leitet `/api/` an den REST-Server auf Container-Port 8081 weiter. Direkt ist die API am Host über Port 8080 erreichbar.
- Der REST-Server prüft die PDF-Signatur, speichert die Datei in MinIO und schreibt Dokument und OCR-Auftrag gemeinsam in PostgreSQL.
- Ein Hintergrundprozess sendet ausstehende Aufträge an die persistente Queue `document.created`. Er entfernt sie aus PostgreSQL erst nach Bestätigung durch RabbitMQ. Bei kurzzeitigen Ausfällen wiederholt er den Versand. Wenn RabbitMQ bestätigt und der Prozess vor dem Datenbank-Commit abbricht, kann derselbe Auftrag erneut zugestellt werden.
- Der OCR-Worker protokolliert Dokument-ID und Storage-Schlüssel. Die Texterkennung folgt in Sprint 4.
- Der JSON-Endpunkt für bestehende Clients bleibt verfügbar. Seine OCR-Nachrichten enthalten einen leeren Storage-Schlüssel.
