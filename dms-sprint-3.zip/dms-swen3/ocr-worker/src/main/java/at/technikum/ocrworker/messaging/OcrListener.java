package at.technikum.ocrworker.messaging;

import at.technikum.ocrworker.config.RabbitMQConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;


@Component
public class OcrListener {

    //Infos überProgrammablauf ausgeben
    private static final Logger log = LoggerFactory.getLogger(OcrListener.class);

    //Sobald Nachricht in Queue, ruft Spring Methode auf
    @RabbitListener(queues = RabbitMQConfig.DOCUMENT_CREATED_QUEUE)
    public void onDocumentCreated(DocumentCreatedMessage message) {
        log.info("Received document {} for OCR processing (storage key: {})",
                message.documentId(), message.storageKey());
    }
}
